
import 'dart:core';
import 'package:flutter/material.dart';

String balance = "";
String publicKey = "";
String sendAddress = "";
String verificationCode = "";
final GlobalKey<ScaffoldState> scaffoldKey = new GlobalKey<ScaffoldState>();